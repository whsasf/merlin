# common

This role defines common roles that need to be executed on every host.
This is done by defining them as dependencies in meta/main.yml.
