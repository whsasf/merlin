# timezone

Sets the timezone.

# Example Playbook

```
---
- hosts: all
  roles:
  - timezone

  vars:
   timezone: America/Los_Angeles
```
