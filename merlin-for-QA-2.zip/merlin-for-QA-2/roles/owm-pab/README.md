# owm-pab

Installs the OWM PAB server backend or proxy.

## Role configuration


The following attributes are required:

For backends:
* pab_version - defined in 'group/pabcal'
* pabcal_cassmeta_endpoint_port - defined  in 'group/pabcal'

For proxies:
* pab_proxy_version - defined in 'group/fep'

