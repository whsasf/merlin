# owm-cal

Installs the OWM CAL server backend or proxy.

## Role configuration

The following attributes are required:

For backends:
* cal_version - defined in 'group/pabcal'
* pabcal_cassmeta_endpoint_port - defined  in 'group/pabcal'

For proxies:
* cal_proxy_version - defined in 'group/fep'

