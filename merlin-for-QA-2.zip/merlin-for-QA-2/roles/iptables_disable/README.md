# Disable iptables

This role disables iptables/firewall based on OS type and version

  - Disables iptables for CentOS/RHEL 6
  - Disables firewall for CentOS/RHEL 7
