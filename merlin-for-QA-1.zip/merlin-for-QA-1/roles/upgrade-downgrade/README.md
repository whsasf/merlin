# upgrade-downgrade

Role to provide tools for upgrade and downgrade of the owm- RPM pacakges on system.

# /tmp/compare_versions.sh
This script will be installed on the target host to help determine if the installation is 
either an upgrade or a downgrade or it is an existing version that requires no action
