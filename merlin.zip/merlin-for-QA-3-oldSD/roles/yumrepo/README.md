# yum.repos.d/CentOS

This role copies the CentOS-nnn.repo files to /etc/yum.repos.d/ so that
CentOS7 will be able to install dependent RPM packages such as PERL
when installing the Nagios Plugins
 
