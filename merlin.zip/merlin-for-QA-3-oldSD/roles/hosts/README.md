# hosts

This role generates the /etc/hosts for all nodes. It relies on an agreement
of what interface is used for what purpose. This follows from the reference
architecture.
