EPEL Repository
===============

Installs the EPEL repository (Extra Packages for Enterprise Linux) for RHEL/CentOS.

Example Playbook
----------------

```
    - hosts: servers
      roles:
        - { role: epel }
```

