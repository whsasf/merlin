# sncr-search

Installs the Synchronoss search (micro)service.

