# OWM RPM Repository

Installs the OWM repository for RHEL/CentOS.

# Example Playbook

```
    - hosts: servers
      roles:
        - { role: owm-repo }
```
