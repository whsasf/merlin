# owm-queue-search

Role to install the owm-queue-search on system.

## Host vars configuration
This variables needs to configured properly in host_vars/site1qadminsearch01, host_vars/site1qadminsearch02,etc for qadminsearch nodes installation.

## Role Configuration:
Variables which need to configured in vars/main.yml:

* queue_search_version(default: 1.0.0.1)