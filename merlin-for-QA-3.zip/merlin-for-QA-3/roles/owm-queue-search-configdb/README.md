# owm-queue-admin

Role to install the owm-queue-admin on system.

## Host vars configuration
This variables needs to configured properly in host_vars/site1qadminsearch01, host_vars/site1qadminsearch02,etc for qadminsearch nodes installation.

## Role Configuration:
Variables which need to configured in vars/main.yml:

* queue_admin_version(default: 1.0.0.1)
