# hostname

This role sets the hostname based on inventory data.

It is possible to skip the hostname configuration (e.g. for the cassandra blobstore nodes) by settings

skip_hostnames: "true"


